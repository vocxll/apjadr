# All Purpose Junk & Debris Removal Website

Open `index.html` in a browser to preview the website.

Before publishing, replace:
- Phone number `(000) 000-0000`
- Email `info@allpurposejunk.com`
- Service area
- Sample customer testimonials with verified reviews
- The two Unsplash hero/about images if you want company-owned photos

The quote form is currently a front-end demo. Connect it to an email service, form backend, or CRM before using it for real customer submissions.
